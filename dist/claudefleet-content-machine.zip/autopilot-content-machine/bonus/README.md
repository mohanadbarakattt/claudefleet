# Bonus material

Included free with this machine. It is supporting reference, not part of the
pipeline — the machine runs fine without it.

- `prompt-vault/` — see its own README for what's inside and how it complements
  the stages in `01-architecture.md`.
